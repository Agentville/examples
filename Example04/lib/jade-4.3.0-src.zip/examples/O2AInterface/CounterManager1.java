package examples.O2AInterface;

public interface CounterManager1 {
	public void activateCounter();
}


/**
 * interface exposes the methods of the agent that you want to provide application
 * 
 * @author Giovanni Iavarone - Michele Izzo
 */