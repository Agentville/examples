package examples.O2AInterface;


public interface CounterManager2 {
	public void deactivateCounter();
}
/**
 * Interface exposes the methods of the agent that you want to provide application
 * 
 * @author Giovanni Iavarone - Michele Izzo
 */